---
title: Stock Scope AI
emoji: 📈
colorFrom: green
colorTo: blue
sdk: streamlit
sdk_version: "1.28.0"
app_file: app.py
pinned: false
---


# 📊 Stock Scope AI

An AI-powered tool for analyzing stocks with predictions, news sentiment, and recommendations.
